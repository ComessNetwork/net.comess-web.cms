<?php
/**
 * @author	Philipp Bornemann
 * @copyright	2013-2014 Comess Web.Net
 * @license	GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 */
require_once('./global.php');
wcf\system\request\RequestHandler::getInstance()->handle('cms', true);
?>