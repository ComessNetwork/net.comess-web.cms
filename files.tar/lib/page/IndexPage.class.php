<?php
namespace cms\page;
use wcf\page\AbstractPage;
use wcf\system\WCF;

/**
 * @author	Philipp Bornemann
 * @copyright	2013-2014 Comess Web.Net
 * @license	GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 */
class IndexPage extends AbstractPage {
	const AVAILABLE_DURING_OFFLINE_MODE = true;
	
	/**
	 * @see	wcf\page\AbstractPage::$activeMenuItem
	 */
	public $activeMenuItem = 'cms.header.menu.index';
	
	/**
	 * @see	wcf\page\IPage::readData()
	 */
	public function readData() {
		parent::readData();
		
		// remove default breadcrumb entry and set current page as 'website'
		if (PageMenu::getInstance()->getLandingPage()->menuItem == 'cms.header.menu.index') {
			WCF::getBreadcrumbs()->remove(0);
				
			MetaTagHandler::getInstance()->addTag('og:url', 'og:url', LinkHandler::getInstance()->getLink('Index', array('application' => 'cms')), true);
			MetaTagHandler::getInstance()->addTag('og:type', 'og:type', 'website', true);
			MetaTagHandler::getInstance()->addTag('og:title', 'og:title', WCF::getLanguage()->get(PAGE_TITLE), true);
			MetaTagHandler::getInstance()->addTag('og:description', 'og:description', WCF::getLanguage()->get(PAGE_DESCRIPTION), true);
		}
	}
}
?>