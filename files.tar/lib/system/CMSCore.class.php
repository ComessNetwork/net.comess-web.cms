<?php
namespace cms\system;
use wcf\system\application\AbstractApplication;
use wcf\system\WCF;

/**
 * @author	Philipp Bornemann
 * @copyright	2013-2014 Comess Web.Net
 * @license	GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 */
class CMSCore extends AbstractApplication {
	/**
	 * @see	wcf\system\application\AbstractApplication::$abbreviation
	 */
	protected $abbreviation = 'cms';
}
?>