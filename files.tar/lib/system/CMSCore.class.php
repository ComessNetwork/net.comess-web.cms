<?php
namespace cms\system;
use cms\data\page\Page;
use wcf\system\menu\page\PageMenu;
use wcf\system\application\AbstractApplication;
use wcf\system\breadcrumb\Breadcrumb;
use wcf\system\request\LinkHandler;
use wcf\system\WCF;

/**
 * @author	Philipp Bornemann
 * @copyright	2013-2014 Comess Web.Net
 * @license	GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 */
class CMSCore extends AbstractApplication {
	/**
	 * @see	wcf\system\application\AbstractApplication::$abbreviation
	 */
	protected $abbreviation = 'cms';
	
	/**
	 * Sets the page breadcrumbs.
	 */
	public function setBreadcrumbs(Page $page = null) {
		// add index page
		if (PageMenu::getInstance()->getLandingPage()->menuItem != 'cms.header.menu.index') {
			WCF::getBreadcrumbs()->add(new Breadcrumb(WCF::getLanguage()->get('cms.header.menu.index'), LinkHandler::getInstance()->getLink('Index', array(
				'application' => 'cms'
			))));
		}
		
		// add page
		if ($page !== null) {
			WCF::getBreadcrumbs()->add($page->getBreadcrumb());
		}
	}
}
?>